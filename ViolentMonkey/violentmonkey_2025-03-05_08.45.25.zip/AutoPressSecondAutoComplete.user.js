// ==UserScript==
// @name        AutoPressSecondAutoComplete
// @namespace   Violentmonkey Scripts
// @match       https://dev.azure.com/hexagonmi/MI-Genesis/_git/GenHexMetrologyReporting/*
// @match       https://dev.azure.com/hexagonmi/MI-Genesis/_git/GenHex_MR_AMAnalytics/*
// @grant       none
// @version     1.0
// @author      -
// @description 11/6/2023, 12:23:50 PM
// ==/UserScript==

const userName = "Kailean O'Keefe";

(function (history) {
  const pushState = history.pushState;
  const replaceState = history.replaceState;

  // Override pushState
  history.pushState = function (state, title, url) {
    const result = pushState.apply(history, arguments);
    window.dispatchEvent(new Event('urlChange')); // Dispatch custom event
    return result;
  };

  // Override replaceState
  history.replaceState = function (state, title, url) {
    const result = replaceState.apply(history, arguments);
    window.dispatchEvent(new Event('urlChange')); // Dispatch custom event
    return result;
  };

  // Add event listener for the custom urlChange event
  window.addEventListener('urlChange', () => {
    checkURLChange(); // Trigger when URL changes
  });

  window.addEventListener('popstate', () => {
    checkURLChange(); // Trigger when URL changes
  });
})(window.history);

const checkURLChange = () => {
  const currentURL = window.location.href;
  if (currentURL.includes('/pullrequest/')) {
    waitForButton();
  }
}

const delay = ms => new Promise(res => setTimeout(res, ms));

const waitForButton = async () => {
  let autoCompleteButton = null
  let retryCount = 5

  while (!autoCompleteButton && retryCount > 0) {
    autoCompleteButton = document.querySelector("button[class='bolt-split-button-main bolt-button bolt-icon-button enabled primary bolt-focus-treatment']")
    await delay(500);
    retryCount--;
  }

  if (!autoCompleteButton || autoCompleteButton.innerHTML.toLocaleLowerCase().includes('cancel')) return

  const containsUserName = document.querySelector("div[class=\"pr-secondary-title-row-persona flex-row rhythm-horizontal-8 flex-center flex-wrap\"]")?.innerHTML.includes(userName)
  if (!containsUserName) {
    return
  }

  autoCompleteButton.onclick = async () => {
    await delay(1000)
    const finishHim = document.querySelector("button[id='__bolt-complete']");
    finishHim.click()
  }
  autoCompleteButton.click()
}

waitForButton()