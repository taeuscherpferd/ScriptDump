// ==UserScript==
// @name        Collapse_Closed_On_Jira
// @namespace   Violentmonkey Scripts
// @match       https://hexagon.atlassian.net/jira/software/c/projects/*/boards/*
// @grant       none
// @version     1.0
// @author      -
// @description 11/2/2023, 10:46:33 AM
// ==/UserScript==

const collapseClosedButton = document.createElement('button')

function scrollList(scrollListElement, amount) {
  // Set the new scroll position
        scrollListElement.scrollTop += amount;
        // Wait for the scroll event to finish
        return new Promise(resolve => {
            scrollListElement.addEventListener('scroll', function handler() {
                scrollListElement.removeEventListener('scroll', handler);
                resolve();
            });
        });
}

function collapseAllInArea() {
  document.querySelectorAll("div[data-testid='platform-board-kit.ui.swimlane.swimlane-content']").forEach((issue) => {
    const issueStatus = issue.querySelector("span[data-testid='platform-board-kit.ui.swimlane.lozenge--text']")
    if (issueStatus && issueStatus.innerHTML.toLocaleLowerCase() === "closed" && issue.ariaExpanded === "true") {
      issue.click()
    }
  })
}

async function CollapseAllOnScroll(scrollListElement) {
  let cursor = 0
  const originalPosition = scrollListElement.scrollTop
  while (cursor <= (scrollListElement.scrollHeight - scrollListElement.clientHeight)){
    cursor += scrollListElement.clientHeight
    collapseAllInArea()
    await scrollList(scrollListElement, scrollListElement.clientHeight)
  }
  scrollListElement.scrollTop = originalPosition
}

collapseClosedButton.style.order = 1;
collapseClosedButton.style.display = "flex";
collapseClosedButton.style.alignItems = "center";
collapseClosedButton.innerText = "Collapse Closed";
collapseClosedButton.onclick = () => {
  console.log("collapsing")
  let scrollListElement = document.querySelector("div[data-testid='platform-board-kit.ui.board.scroll.board-scroll']")
  if (!scrollListElement) {
    console.log("earlyOut")
    return
  }
  CollapseAllOnScroll(scrollListElement)

}

const delay = ms => new Promise(res => setTimeout(res, ms));

async function waitForFilters() {
  let retryCount = 0;
  let filters = null;
  let retVal = null;

  while (retryCount < 10) {
    retryCount++;
    filters = document.querySelector("span[data-testid='filters.common.ui.list.quick-filters-filter']");
    retVal = filters?.parentElement?.parentElement?.parentElement?.parentElement?.parentElement?.parentElement?.appendChild(collapseClosedButton) ?? null
    if (retVal !== null) break;
    await delay(1000);
  }
  return filters
}

waitForFilters();

// Collapsed tag id
// <span data-testid="platform-board-kit.ui.swimlane.lozenge--text" class="css-1341ess" style="max-width: calc(200px - var(--ds-space-100, 8px));">Closed</span>

// Issue row Id
// <div class="sc-1mvpb7m-0 bGcYai" data-test-id="platform-board-kit.ui.swimlane.swimlane-content">