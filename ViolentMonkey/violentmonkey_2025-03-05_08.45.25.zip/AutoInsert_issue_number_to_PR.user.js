// ==UserScript==
// @name        AutoInsert_issue_number_to_PR
// @namespace   Violentmonkey Scripts
// @match       https://dev.azure.com/hexagonmi/MI-Genesis/_git/GenHexMetrologyReporting/*
// @match       https://dev.azure.com/hexagonmi/MI-Genesis/_git/GenHex_MR_AMAnalytics/*
// @grant       none
// @version     1.0
// @author      -
// @description 4/24/2023, 3:59:02 PM
// ==/UserScript==

(function (history) {
  const pushState = history.pushState;
  const replaceState = history.replaceState;

  // Override pushState
  history.pushState = function (state, title, url) {
    const result = pushState.apply(history, arguments);
    window.dispatchEvent(new Event('urlChange')); // Dispatch custom event
    return result;
  };

  // Override replaceState
  history.replaceState = function (state, title, url) {
    const result = replaceState.apply(history, arguments);
    window.dispatchEvent(new Event('urlChange')); // Dispatch custom event
    return result;
  };

  // Add event listener for the custom urlChange event
  window.addEventListener('urlChange', () => {
    checkURLChange(); // Trigger when URL changes
  });

  window.addEventListener('popstate', () => {
    checkURLChange(); // Trigger when URL changes
  });
})(window.history);

const checkURLChange = () => {
  const currentURL = window.location.href;
  if (currentURL.includes('pullrequestcreate')) {
    main();
  }
}

const main = async () => {
  const titleInput = await isElementLoaded('input[aria-label="Enter a title"]');
  const branchText = await isElementLoaded('div[class="version-dropdown scroll-hidden bolt-dropdown-expandable bolt-expandable-button inline-flex-row"]')
  const textToInsert = branchText ? branchText.textContent.match(/AMRPT-\d*/gi)[0] : window.location.href.match(/AMRPT-\d*/gi)[0]
  const isFeature = branchText && branchText.textContent.toLowerCase().includes("/feature/")

  if (titleInput.value.includes(textToInsert.toUpperCase())) {
    return;
  }

  titleInput.value = `[${textToInsert.toUpperCase()}] ${isFeature ? "feat:" : "bug:"} ${titleInput.value}`
}

const isElementLoaded = async selector => {
  let timeoutCount = 0;
  while (document.querySelector(selector) === null || timeoutCount < 5) {
    await new Promise(resolve => requestAnimationFrame(resolve))
    ++timeoutCount
  }
  return document.querySelector(selector);
};

main()